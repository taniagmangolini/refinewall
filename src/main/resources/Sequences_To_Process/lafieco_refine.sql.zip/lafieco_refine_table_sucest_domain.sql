
-- --------------------------------------------------------

--
-- Estrutura da tabela `sucest_domain`
--

DROP TABLE IF EXISTS `sucest_domain`;
CREATE TABLE `sucest_domain` (
  `id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `domain` int(11) DEFAULT NULL,
  `sucest_id` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
