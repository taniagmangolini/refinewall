
--
-- Indexes for dumped tables
--

--
-- Indexes for table `blast_result`
--
ALTER TABLE `blast_result`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_blast_id` (`id`),
  ADD KEY `FKs9b7al4c8694j99ggcasmau5l` (`sucest_id`),
  ADD KEY `FK4ecqw6f7a0x7x65u40sx6uhs9` (`search_history_id`),
  ADD KEY `idx_unique_identifier` (`unique_identifier`),
  ADD KEY `idx_sucest_blast` (`sucest_busca`);

--
-- Indexes for table `search_history`
--
ALTER TABLE `search_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sucest`
--
ALTER TABLE `sucest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sucest_blast`
--
ALTER TABLE `sucest_blast`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKoqr2lp4j52wm3wri1l00sf9tj` (`sucest_id`);

--
-- Indexes for table `sucest_domain`
--
ALTER TABLE `sucest_domain`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK9eax7ba8k34l9uf5ndc0epc1d` (`sucest_id`);

--
-- Indexes for table `sucest_sequence`
--
ALTER TABLE `sucest_sequence`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKe8u27qnmdpg6xdcwk5h3oighv` (`sucest_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blast_result`
--
ALTER TABLE `blast_result`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=575499;
--
-- AUTO_INCREMENT for table `search_history`
--
ALTER TABLE `search_history`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sucest`
--
ALTER TABLE `sucest`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1276;
--
-- AUTO_INCREMENT for table `sucest_blast`
--
ALTER TABLE `sucest_blast`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sucest_domain`
--
ALTER TABLE `sucest_domain`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sucest_sequence`
--
ALTER TABLE `sucest_sequence`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1228;