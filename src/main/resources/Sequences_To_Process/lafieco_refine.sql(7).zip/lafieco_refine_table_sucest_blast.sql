
-- --------------------------------------------------------

--
-- Estrutura da tabela `sucest_blast`
--

CREATE TABLE `sucest_blast` (
  `id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `disabled_at` datetime DEFAULT NULL,
  `keywords` varchar(15000) DEFAULT NULL,
  `sucest_id` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
