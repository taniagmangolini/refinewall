
-- --------------------------------------------------------

--
-- Estrutura da tabela `search_history`
--

CREATE TABLE `search_history` (
  `id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `sequence` varchar(5000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
